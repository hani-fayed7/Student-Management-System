package studentmanagementsystem;

public class Student {
    String name;
    int age;
    String phoneNumber;
    String ID;

    public Student(String name, int age,String pNumber,String enrollmentNumber) {
        this.name = name;
        this.age = age;
        this.phoneNumber = pNumber;
        this.ID = enrollmentNumber;
       
    }
}
